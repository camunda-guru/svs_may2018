import {Component} from "@angular/core"

@Component({
  selector:'feedback-app',
  templateUrl:'./app/feedback/feedback.component.html',
  styleUrls:['./app/feedback/feedback.component.css']

})
export class FeedbackComponent
{

}