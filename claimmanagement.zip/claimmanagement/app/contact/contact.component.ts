import {Component} from "@angular/core"

@Component({
  selector:'contact-app',
  templateUrl:'./app/contact/contact.component.html',
  styleUrls:['./app/contact/contact.component.css']

})
export class ContactComponent
{

}