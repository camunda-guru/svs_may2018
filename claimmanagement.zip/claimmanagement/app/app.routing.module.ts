import {NgModule} from "@angular/core";
import {Routes, RouterModule} from "@angular/router";
import { HomeComponent } from "./home/home.component";
import { ContactComponent } from "./contact/contact.component";
import { ClaimServiceComponent } from "./claimservice/claimservice.component";
import { ClaimComponent } from "./claim/claim.component";
import { FeedbackComponent } from "./feedback/feedback.component";
import { ComplaintsComponent } from "./complaints/complaints.component";



const routes:Routes=[{
    path: 'Home',
    component: HomeComponent
},
    {
        path: 'Contact',
        component: ContactComponent
    },
    {
        path: 'Claim_Service',
        component: ClaimServiceComponent
    },

    {
        path: 'Claim',
        component: ClaimComponent
    },

    {
        path: 'Feedback',
        component: FeedbackComponent
    },
    {
        path: 'Complaints',
        component: ComplaintsComponent
    },

];

@NgModule({
    imports:[RouterModule.forRoot(routes)],
    exports:[RouterModule]
})
export class AppRoutingModule
{
}
