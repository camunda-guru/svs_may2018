import {Component} from "@angular/core"

@Component({
    selector:'claim-header',
    templateUrl:'./app/app.component.html',
    styleUrls:['./app/app.component.css']

})
export class AppComponent
{
    private logoPath:string;
    private bannerPath:string;
    private vehicleBanner:string;
    constructor()
    {
        this.logoPath="./app/resources/sriramins.png";
        this.bannerPath="./app/resources/sriramvehicle.png";
        this.vehicleBanner="./app/resources/srirambanner.jpg";
    }


}