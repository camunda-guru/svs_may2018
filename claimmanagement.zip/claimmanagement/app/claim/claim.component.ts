import {Component} from "@angular/core"

@Component({
  selector:'claim-app',
  templateUrl:'./app/claim/claim.component.html',
  styleUrls:['./app/claim/claim.component.css']

})
export class ClaimComponent
{

}