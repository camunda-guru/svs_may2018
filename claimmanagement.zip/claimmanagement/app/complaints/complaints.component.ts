import {Component} from "@angular/core"

@Component({
  selector:'complaints-app',
  templateUrl:'./app/complaints/complaints.component.html',
  styleUrls:['./app/complaints/complaints.component.css']

})
export class ComplaintsComponent
{

}