import {Component, OnInit} from "@angular/core"
import { MenuService } from "../service/service.menuservice";

@Component({
    selector:'site-menu',
    templateUrl:'./app/menu/menu.component.html',
    styleUrls:['./app/menu/menu.component.css'] 

})
export class MenuComponent implements OnInit
{

  private menuItems:any=[];

   constructor(private menuService:MenuService)
   {

   }

   ngOnInit()
   {
       this.menuService.getMenuData().then(response=>{

            response.forEach(obj=>{
                this.menuItems.push(obj);
            })

       })
   }


}