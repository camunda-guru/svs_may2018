import { NgModule } from "@angular/core";
import {BrowserModule} from "@angular/platform-browser"
import {CommonModule} from "@angular/common"
import { AppComponent } from "./app.component";
import { MenuComponent } from "./menu/menu.component";
import { MenuService } from "./service/service.menuservice";
import { AppRoutingModule } from "./app.routing.module";
import { HomeComponent } from "./home/home.component";
import { ClaimComponent } from "./claim/claim.component";
import { ClaimServiceComponent } from "./claimservice/claimservice.component";
import { ComplaintsComponent } from "./complaints/complaints.component";
import { FeedbackComponent } from "./feedback/feedback.component";
import { ContactComponent } from "./contact/contact.component";
@NgModule({
  imports:[BrowserModule,CommonModule,AppRoutingModule],
  declarations:[AppComponent,MenuComponent,HomeComponent,ClaimComponent,ClaimServiceComponent,ComplaintsComponent,FeedbackComponent,ContactComponent],
  providers:[MenuService],
  bootstrap:[AppComponent]
})
export class AppModule
{



}