import {Component} from "@angular/core"

@Component({
  selector:'claimservice-app',
  templateUrl:'./app/claimservice/claimservice.component.html',
  styleUrls:['./app/claimservice/claimservice.component.css']

})
export class ClaimServiceComponent
{

}