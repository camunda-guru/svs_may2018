import {Menu} from "./model.menu"

export const MenuData:Menu[]=[
  new Menu(1,"Home"),
  new Menu(2,"Contact"),
  new Menu(3,"Claim_Service"),
  new Menu(4,"Complaints"),
  new Menu(5,"Claim"),
  new Menu(6,"Feedback"),

];