export class Menu
{
    private menuId:number;
    private name:string;
    constructor(id:number,name:string)
    {
        this.menuId=id;
        this.name=name;
    }

    get MenuId():number
    {
        return this.menuId;
    }
    get Name():string
    {
        return this.name;
    }

}