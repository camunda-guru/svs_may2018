import {Injectable} from "@angular/core"
import {Menu} from "../model/model.menu"
import { MenuData } from "../model/model.menudata";
@Injectable()
export class MenuService
{

   getMenuData():Promise<Menu[]>
   {
      return Promise.resolve(MenuData);
   }


}